#include "persona.h"

Persona::Persona(){
    nombre="S/N";
    casado=false;
};
void Persona::setNombre(string nombre){
    this->nombre=nombre;
};
void Persona::setCasado(bool casado){
    this->casado=casado;
};
string Persona::getNombre(){
    return nombre;
};
bool Persona::getCasado(){
    return casado;
};
