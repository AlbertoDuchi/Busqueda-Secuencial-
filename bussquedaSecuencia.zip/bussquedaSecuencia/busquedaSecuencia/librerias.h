#ifndef LIBRERIAS_H
#define LIBRERIAS_H
#include<iostream>
#include<vector>
#include<iomanip>
#include "persona.h"
using namespace std;
void menu();
void ingresoDatos(vector<Persona> &lista);
void buscarDato(vector<Persona> lista, string nombreBuscar);
void mostrarDatos(vector<Persona> lista, string titulo);
#endif // LIBRERIAS_H
