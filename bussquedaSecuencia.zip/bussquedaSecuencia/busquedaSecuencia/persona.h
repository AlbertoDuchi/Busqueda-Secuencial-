#ifndef PERSONA_H
#define PERSONA_H

#include<iostream>
using namespace std;
class Persona{
    private:
        string nombre;
        bool casado;
    public:
        Persona();
        void setNombre(string nombre);
        void setCasado(bool casado);
        string getNombre();
        bool getCasado();
};
#endif // PERSONA_H
