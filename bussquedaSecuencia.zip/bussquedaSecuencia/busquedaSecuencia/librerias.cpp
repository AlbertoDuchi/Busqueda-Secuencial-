#include "librerias.h"

void menu(){
    cout<<"1.- Ingreso datos\n";
    cout<<"2.- Mostrar datos\n";
    cout<<"3.- Buscar datos\n";
    cout<<"4.- Salir\n";
    cout<<"Seleccione una opcion....: ";
};
void ingresoDatos(vector<Persona> &lista){
    string nombre;
    int bandera;
    bool casado;
    Persona objPersona;
    cout<<"Ingrese el nombre: ";
    getline(cin>>ws,nombre);
    do{
        bandera=0;
        cout<<"Casado: NO (0) Si(1): ";
        cin>>casado;
        if (cin.fail()){
            cin.clear();
            cout<<"\tError\n";
            bandera=1;
        };
    }while(bandera==1);
    //guardar
    objPersona.setNombre(nombre);
    objPersona.setCasado(casado);
    lista.push_back(objPersona);
};
void buscarDato(vector<Persona> lista, string nombreBuscar){
    bool  encontrado=false;
    int contador=0, pos=-1;
    if(lista.size()>0){
        cout<<"Nombre a Buscar: ";
        getline(cin>>ws,nombreBuscar);
        for(auto i: lista){
            if(i.getNombre()==nombreBuscar){
                encontrado=true;
                pos=contador;
                break;
            }
            contador++;
        }
        if(encontrado){
            cout<<nombreBuscar<<" Encontrado en la pos: "<<pos+1<<endl;
        }else{
            cout<<nombreBuscar<<" No encontrado\n";
        }
    }else{
        cout<<"Lista vacia\n";
    }
};
void mostrarDatos(vector<Persona> lista, string titulo){
    cout<<"\n***** "<<titulo<<" *****\n";
    if(lista.size()>0){
        cout<<setw(15)<<left<<"Nombres"<<setw(15)<<left<<"Apellidos"<<endl;
        for(auto i: lista){
            string estado=(i.getCasado())?"Casado":"No Casado";
            cout<<setw(15)<<left<<i.getNombre()<<setw(50)<<left<<estado<<endl;
        }
    }else{
        cout<<"Lista vacia\n";
    }
};
