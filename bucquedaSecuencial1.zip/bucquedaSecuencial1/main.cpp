#include<iostream>
#include<vector>
#include<iomanip>
#include "persona.h"
#include "librerias.h"
using namespace std;
int main(){
    vector<Persona> lista;
    string nombreBuscar;
    int op;
    system("color 97");
    do{
        system("cls");
        menu();
        cin>>op;
        switch (op){
            case 1:
                system("cls");
                cout<<"\n***** Ingreso de Datos ********\n\n";
                ingresoDatos(lista);
                system("pause");
                break;
            case 2:
                system("cls");
                mostrarDatos(lista, "Listado de Datos");
                system("pause");
                break;
            case 3:
                system("cls");
                buscarDato(lista, nombreBuscar);
                system("pause");
                break;
            case 4:
                system("cls");
                cout<<"Programa finalizado\n";
                system("pause");
                break;
            default:
                break;
        }
    }while(op!=4);
    return 0;
}
